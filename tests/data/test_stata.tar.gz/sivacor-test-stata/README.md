# Test files for SIVACOR

This is a plausible minimal working example of code that should work on SIVACOR.

Versions:

- For all versions: main file = `main.do`
- Test code for Stata (any version) that works, Scenario B: <https://github.com/SIVACOR/sivacor-test-stata>
- Test code for Stata (any version) that works, Scenario A (`main.do` in a non-root directory): <https://github.com/SIVACOR/sivacor-test-stata/tree/scenario-A>
- Test code for Stata (any version) that should lead a properly reported failure: <https://github.com/SIVACOR/sivacor-test-stata/tree/stata-fail>

print("Hello World")
data_vector <- c(2, 2)
cat("[", data_vector, "]", file = "output.txt", sep = "")
cat("\nSuccessfully wrote 'Hello World' to console and [2,2] to output.txt\n")

#!/bin/bash

R CMD BATCH penguins_descriptives.R

global sscdate "2026-04-30"
global sscmirror "raw.githubusercontent.com/labordynamicsinstitute/ssc-mirror/$sscdate/" 
net install synth, from(https://${sscmirror}fmwww.bc.edu/repec/bocode/s) all
use synth_smoking
tsset state year
synth cigsale beer(1984(1)1988) lnincome retprice age15to24 cigsale(1988) cigsale(1980) cigsale(1975), trunit(3) trperiod(1989)

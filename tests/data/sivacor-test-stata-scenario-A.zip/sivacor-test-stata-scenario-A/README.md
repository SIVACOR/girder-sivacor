This is just a placeholder.

This is a Scenario A.
